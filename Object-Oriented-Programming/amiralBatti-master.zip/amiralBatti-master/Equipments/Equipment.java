package Equipments;

public class Equipment {
	
}
