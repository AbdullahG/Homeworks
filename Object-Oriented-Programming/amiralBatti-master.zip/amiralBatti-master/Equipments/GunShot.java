package Equipments;

public class GunShot extends Equipment {

}
