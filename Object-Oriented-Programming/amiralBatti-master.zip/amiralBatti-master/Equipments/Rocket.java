package Equipments;

public class Rocket extends Equipment {

}
