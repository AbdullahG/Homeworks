package Equipments;

public class HandBomb extends Equipment {

}
